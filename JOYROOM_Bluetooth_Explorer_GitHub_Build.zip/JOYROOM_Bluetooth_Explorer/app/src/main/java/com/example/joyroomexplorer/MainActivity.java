package com.example.joyroomexplorer;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private boolean scanning = false;
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private final Map<String, String> reports = new LinkedHashMap<>();
    private final List<BluetoothGattCharacteristic> readableQueue = new ArrayList<>();
    private LinearLayout root, deviceList;
    private TextView status, log;
    private Button scanButton, stopButton, exportButton;
    private static final int REQ_PERMS = 100;
    private static final int REQ_EXPORT = 200;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        BluetoothManager bm = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        adapter = bm.getAdapter();
        buildUi();
        if (adapter == null) { append("هذا الهاتف لا يدعم Bluetooth."); setButtons(false); return; }
        requestNeededPermissions();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24);
        scroll.addView(root); setContentView(scroll);
        TextView title = new TextView(this); title.setText("JOYROOM Bluetooth Explorer"); title.setTextSize(23); title.setPadding(0,0,0,12); root.addView(title);
        TextView note = new TextView(this); note.setText("فاحص BLE وGATT — يعرض المعلومات المتاحة للنظام فقط. لا يحاول تجاوز الاقتران أو المصادقة."); note.setTextSize(14); root.addView(note);
        status = new TextView(this); status.setText("الحالة: جاهز"); status.setPadding(0,14,0,10); root.addView(status);
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); root.addView(buttons);
        scanButton = new Button(this); scanButton.setText("بدء المسح"); buttons.addView(scanButton, new LinearLayout.LayoutParams(0,-2,1));
        stopButton = new Button(this); stopButton.setText("إيقاف"); buttons.addView(stopButton, new LinearLayout.LayoutParams(0,-2,1));
        exportButton = new Button(this); exportButton.setText("تصدير التقرير"); root.addView(exportButton);
        TextView devTitle = new TextView(this); devTitle.setText("الأجهزة المكتشفة (اضغط للاتصال)"); devTitle.setTextSize(18); devTitle.setPadding(0,16,0,4); root.addView(devTitle);
        deviceList = new LinearLayout(this); deviceList.setOrientation(LinearLayout.VERTICAL); root.addView(deviceList);
        TextView logTitle = new TextView(this); logTitle.setText("التقرير والسجل"); logTitle.setTextSize(18); logTitle.setPadding(0,16,0,4); root.addView(logTitle);
        log = new TextView(this); log.setTextSize(13); log.setTextIsSelectable(true); log.setMovementMethod(new ScrollingMovementMethod()); root.addView(log);
        scanButton.setOnClickListener(v -> startScan());
        stopButton.setOnClickListener(v -> stopScan());
        exportButton.setOnClickListener(v -> exportReport());
        setButtons(false);
    }

    private void setButtons(boolean ready) {
        if (scanButton != null) scanButton.setEnabled(ready);
        if (stopButton != null) stopButton.setEnabled(ready && scanning);
        if (exportButton != null) exportButton.setEnabled(!reports.isEmpty());
    }

    private boolean hasPermission(String p) { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }
    private void requestNeededPermissions() {
        ArrayList<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (!hasPermission(Manifest.permission.BLUETOOTH_SCAN)) needed.add(Manifest.permission.BLUETOOTH_SCAN);
            if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) needed.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (Build.VERSION.SDK_INT >= 23 && !hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), REQ_PERMS);
        else afterPermissions();
    }
    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQ_PERMS) { boolean ok = true; for (int r: results) if (r != PackageManager.PERMISSION_GRANTED) ok = false; if (ok) afterPermissions(); else { status.setText("الحالة: يلزم السماح بإذن Bluetooth / الأجهزة القريبة."); append("تم رفض إذن مطلوب؛ افتح إعدادات التطبيق واسمح بالأجهزة القريبة."); } }
    }
    private void afterPermissions() {
        try { scanner = adapter.getBluetoothLeScanner(); setButtons(adapter.isEnabled()); status.setText(adapter.isEnabled() ? "الحالة: جاهز للمسح" : "الحالة: شغّل Bluetooth أولاً"); }
        catch (SecurityException e) { append("لا توجد صلاحية للوصول إلى Bluetooth: " + e); }
    }

    private void startScan() {
        if (adapter == null || !adapter.isEnabled()) { toast("شغّل Bluetooth أولاً"); return; }
        if (Build.VERSION.SDK_INT >= 31 && (!hasPermission(Manifest.permission.BLUETOOTH_SCAN) || !hasPermission(Manifest.permission.BLUETOOTH_CONNECT))) { requestNeededPermissions(); return; }
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { append("تعذر بدء BLE Scanner. تأكد من تشغيل Bluetooth."); return; }
            found.clear(); deviceList.removeAllViews(); scanning = true; setButtons(true); stopButton.setEnabled(true); scanButton.setEnabled(false);
            status.setText("الحالة: يجري المسح…"); append("\n=== بدء مسح BLE ===");
            scanner.startScan(scanCallback);
        } catch (SecurityException e) { append("فشل المسح بسبب الصلاحيات: " + e.getMessage()); scanning=false; setButtons(true); }
    }
    private void stopScan() {
        try { if (scanner != null && scanning) scanner.stopScan(scanCallback); } catch (Exception ignored) {}
        scanning = false; scanButton.setEnabled(true); stopButton.setEnabled(false);
        status.setText("الحالة: توقف المسح — تم العثور على " + found.size() + " جهاز BLE"); append("انتهى المسح. الأجهزة: " + found.size());
    }
    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) { runOnUiThread(() -> addResult(result)); }
        @Override public void onBatchScanResults(List<ScanResult> results) { runOnUiThread(() -> { for (ScanResult r: results) addResult(r); }); }
        @Override public void onScanFailed(int errorCode) { runOnUiThread(() -> { scanning=false; setButtons(true); status.setText("فشل المسح، رمز الخطأ: " + errorCode); append("Scan failed errorCode=" + errorCode + " (راجع الأذونات، تشغيل Bluetooth، وعدم وجود مسح آخر). "); }); }
    };
    private void addResult(ScanResult r) {
        BluetoothDevice d = r.getDevice(); String address="غير متاح", name=null;
        try { address = d.getAddress(); name = d.getName(); } catch (SecurityException e) { name = null; }
        ScanRecord sr = r.getScanRecord(); if ((name == null || name.isEmpty()) && sr != null) name = sr.getDeviceName();
        if (name == null || name.isEmpty()) name = "جهاز بدون اسم";
        if (address == null) address="غير متاح";
        String key = address; if (found.containsKey(key)) return; found.put(key,d);
        StringBuilder detail = new StringBuilder(); detail.append("الاسم: ").append(name).append("\nالعنوان المعروض: ").append(address).append("\nRSSI: ").append(r.getRssi()).append(" dBm\n");
        if (sr != null) {
            detail.append("Connectable: ").append(r.isConnectable()).append("\n");
            List<ParcelUuid> uuids = sr.getServiceUuids(); detail.append("Advertised service UUIDs: ");
            if (uuids == null || uuids.isEmpty()) detail.append("لا توجد"); else for (ParcelUuid u: uuids) detail.append(u.toString()).append(" "); detail.append("\n");
            byte[] md = sr.getManufacturerSpecificData() == null ? null : flattenManufacturer(sr);
            detail.append("Manufacturer data: ").append(md == null ? "لا توجد/غير معلنة" : bytesHex(md)).append("\n");
            for (ParcelUuid u: sr.getServiceData().keySet()) detail.append("Service data ").append(u).append(": ").append(bytesHex(sr.getServiceData().get(u))).append("\n");
            if (sr.getBytes() != null) detail.append("Raw advertisement bytes: ").append(bytesHex(sr.getBytes())).append("\n");
        }
        reports.put("scan_"+address, detail.toString());
        final String deviceName = name;
        final String deviceAddress = address;
        final String deviceDetail = detail.toString();
        Button item = new Button(this); item.setText(deviceName + "\n" + deviceAddress + "  |  " + r.getRssi() + " dBm"); item.setAllCaps(false); item.setOnClickListener(v -> connect(d, deviceName, deviceAddress, deviceDetail)); deviceList.addView(item);
        append("\n" + detail);
        setButtons(true); scanButton.setEnabled(!scanning); stopButton.setEnabled(scanning); exportButton.setEnabled(true);
    }
    private byte[] flattenManufacturer(ScanRecord sr) {
        android.util.SparseArray<byte[]> data = sr.getManufacturerSpecificData();
        if (data == null || data.size() == 0) return null;
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        for (int i=0;i<data.size();i++) { int id=data.keyAt(i); out.write(id & 255); out.write((id>>8)&255); byte[] b=data.valueAt(i); if (b!=null) out.write(b,0,b.length); }
        return out.toByteArray();
    }
    private void connect(BluetoothDevice device, String name, String address, String scanInfo) {
        try {
            if (gatt != null) { gatt.disconnect(); gatt.close(); gatt=null; }
            append("\n=== الاتصال بـ " + name + " / " + address + " ==="); status.setText("الحالة: الاتصال بـ " + name);
            if (Build.VERSION.SDK_INT >= 23) gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            else gatt = device.connectGatt(this, false, gattCallback);
            reports.put("connection_"+address, "Device: "+name+"\nAddress shown by Android: "+address+"\n"+scanInfo);
        } catch (SecurityException e) { append("فشل الاتصال بسبب الصلاحيات: " + e.getMessage()); }
    }
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int statusCode, int newState) {
            runOnUiThread(() -> { append("GATT connection callback: status="+statusCode+", state="+(newState==BluetoothProfile.STATE_CONNECTED?"CONNECTED":newState==BluetoothProfile.STATE_DISCONNECTED?"DISCONNECTED":newState));
                if (statusCode == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) { status.setText("الحالة: متصل — اكتشاف الخدمات"); try { g.discoverServices(); } catch (SecurityException e) { append("لا توجد صلاحية لاكتشاف الخدمات."); } }
                else if (newState == BluetoothProfile.STATE_DISCONNECTED) status.setText("الحالة: غير متصل"); });
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int statusCode) {
            runOnUiThread(() -> {
                StringBuilder sb = new StringBuilder("\n=== GATT SERVICES (status="+statusCode+") ===\n");
                readableQueue.clear();
                if (statusCode == BluetoothGatt.GATT_SUCCESS) for (BluetoothGattService s: g.getServices()) {
                    sb.append("SERVICE ").append(s.getUuid()).append(" type=").append(s.getType()==BluetoothGattService.SERVICE_TYPE_PRIMARY?"PRIMARY":"SECONDARY").append("\n");
                    for (BluetoothGattCharacteristic c: s.getCharacteristics()) {
                        sb.append("  CHARACTERISTIC ").append(c.getUuid()).append(" properties=").append(properties(c.getProperties())).append(" permissions=").append(c.getPermissions()).append("\n");
                        if ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) readableQueue.add(c);
                        for (BluetoothGattDescriptor d: c.getDescriptors()) sb.append("    DESCRIPTOR ").append(d.getUuid()).append(" permissions=").append(d.getPermissions()).append("\n");
                    }
                } else sb.append("Service discovery failed; status=").append(statusCode).append("\n");
                append(sb.toString()); reports.put("gatt_services", sb.toString()); status.setText("الحالة: اكتشاف الخدمات اكتمل؛ قراءة الخصائص المتاحة");
                readNextCharacteristic();
            });
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int statusCode) {
            byte[] value = c.getValue(); String line="READ "+c.getUuid()+" status="+statusCode+" value="+bytesHex(value)+"\n"; runOnUiThread(() -> { append(line); reports.put("read_"+c.getUuid(),line); readNextCharacteristic(); });
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value, int statusCode) {
            String line="READ "+c.getUuid()+" status="+statusCode+" value="+bytesHex(value)+"\n"; runOnUiThread(() -> { append(line); reports.put("read_"+c.getUuid(),line); readNextCharacteristic(); });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] value=c.getValue(); String line="NOTIFICATION "+c.getUuid()+" value="+bytesHex(value)+"\n"; runOnUiThread(() -> { append(line); reports.put("notify_"+c.getUuid()+"_"+System.currentTimeMillis(),line); });
        }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int statusCode) { runOnUiThread(() -> append("Descriptor write " + d.getUuid() + " status=" + statusCode + "\n")); }
    };
    private void readNextCharacteristic() {
        if (gatt == null) return;
        if (readableQueue.isEmpty()) { status.setText("الحالة: اكتمل الفحص والقراءات المسموح بها"); append("انتهت محاولة قراءة كل الخصائص التي تعلن عن READ. قد ترفض بعض الخصائص القراءة بسبب المصادقة أو حالة الجهاز."); return; }
        BluetoothGattCharacteristic c = readableQueue.remove(0);
        try {
            boolean started;
            if (Build.VERSION.SDK_INT >= 33) started = gatt.readCharacteristic(c) == BluetoothStatusCodes.SUCCESS;
            else started = gatt.readCharacteristic(c);
            if (!started) { String line="READ_NOT_STARTED "+c.getUuid()+"\n"; append(line); reports.put("read_error_"+c.getUuid(),line); readNextCharacteristic(); }
        } catch (SecurityException e) { append("قراءة مرفوضة بسبب الصلاحيات: "+c.getUuid()+"\n"); readNextCharacteristic(); }
    }
    private String properties(int p) { ArrayList<String> x=new ArrayList<>(); if((p&BluetoothGattCharacteristic.PROPERTY_READ)!=0)x.add("READ"); if((p&BluetoothGattCharacteristic.PROPERTY_WRITE)!=0)x.add("WRITE"); if((p&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0)x.add("WRITE_NO_RESPONSE"); if((p&BluetoothGattCharacteristic.PROPERTY_NOTIFY)!=0)x.add("NOTIFY"); if((p&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0)x.add("INDICATE"); if((p&BluetoothGattCharacteristic.PROPERTY_BROADCAST)!=0)x.add("BROADCAST"); if((p&BluetoothGattCharacteristic.PROPERTY_SIGNED_WRITE)!=0)x.add("SIGNED_WRITE"); return x.isEmpty()?"NONE":android.text.TextUtils.join("|",x); }
    private String bytesHex(byte[] b) { if (b==null || b.length==0) return "(empty)"; StringBuilder s=new StringBuilder(); for(byte v:b) s.append(String.format(java.util.Locale.US,"%02X ",v & 255)); return s.toString().trim(); }
    private void append(String s) { if (log != null) log.append(s + (s.endsWith("\n")?"":"\n")); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    private void exportReport() {
        if (reports.isEmpty()) { toast("لا يوجد تقرير بعد؛ ابدأ المسح أولاً."); return; }
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json"); i.putExtra(Intent.EXTRA_TITLE,"joyroom_ble_report.json"); startActivityForResult(i,REQ_EXPORT);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==REQ_EXPORT && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            try (OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                StringBuilder json=new StringBuilder("{\n  \"app\": \"JOYROOM Bluetooth Explorer\",\n  \"generatedAt\": \"").append(new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ",java.util.Locale.US).format(new java.util.Date())).append("\",\n  \"notice\": \"Only data exposed by Android and the device is included; MAC may be randomized or unavailable.\",\n  \"sections\": [\n");
                int n=0; for(Map.Entry<String,String> e: reports.entrySet()) { if(n++>0)json.append(",\n"); json.append("    {\"name\":\"").append(escape(e.getKey())).append("\",\"text\":\"").append(escape(e.getValue())).append("\"}"); }
                json.append("\n  ]\n}\n"); out.write(json.toString().getBytes(StandardCharsets.UTF_8)); toast("تم حفظ التقرير.");
            } catch(Exception e) { toast("تعذر حفظ التقرير: "+e.getMessage()); }
        }
    }
    private String escape(String s) { return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t"); }
    @Override protected void onDestroy() { stopScan(); try { if(gatt!=null){gatt.disconnect();gatt.close();gatt=null;} } catch(Exception ignored){} super.onDestroy(); }
}
